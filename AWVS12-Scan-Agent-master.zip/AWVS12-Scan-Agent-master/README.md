# **AWVS12-Scan-Agent**
## **Usage : python3 Acunetix12-Scan-Agent.py -h**
### **功能：**
### **批量提交任务**
### **批量导出任务结果**
### **批量删除任务**

### **使用：**
### **按config.py中注释说明进行配置即可使用**
